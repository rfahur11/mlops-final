"""
ecommerce_trainer.py
Trainer module untuk TFX Pipeline - E-Commerce Customer Churn Prediction.
Username: rfahrur6045
"""

import os
import tensorflow as tf
import tensorflow_transform as tft
from tfx.components.trainer.fn_args_utils import FnArgs

# ──────────────────────────────────────────────
# Konstanta fitur (harus sama dengan transform)
# ──────────────────────────────────────────────

NUMERICAL_FEATURES = [
    'Tenure',
    'CityTier',
    'WarehouseToHome',
    'HourSpendOnApp',
    'NumberOfDeviceRegistered',
    'SatisfactionScore',
    'NumberOfAddress',
    'Complain',
    'OrderAmountHikeFromlastYear',
    'CouponUsed',
    'OrderCount',
    'DaySinceLastOrder',
    'CashbackAmount',
]

CATEGORICAL_FEATURES = [
    'PreferredLoginDevice',
    'PreferredPaymentMode',
    'Gender',
    'PreferedOrderCat',
    'MaritalStatus',
]

LABEL_KEY = 'Churn'
EMBEDDING_DIM = 16


def transformed_name(key):
    """Menambahkan suffix _xf pada nama fitur hasil transformasi."""
    return key + '_xf'


# ──────────────────────────────────────────────
# Input function
# ──────────────────────────────────────────────

def _gzip_reader_fn(filenames):
    """Membaca file TFRecord berformat GZIP."""
    return tf.data.TFRecordDataset(filenames, compression_type='GZIP')


def _input_fn(file_pattern, tf_transform_output, num_epochs=10, batch_size=64):
    """
    Membuat dataset dari file TFRecord hasil transform.

    Args:
        file_pattern: Pola path ke file TFRecord.
        tf_transform_output: Output dari TFTransform.
        num_epochs: Jumlah epoch untuk iterasi dataset.
        batch_size: Ukuran batch.

    Returns:
        tf.data.Dataset siap digunakan untuk training/evaluasi.
    """
    transform_feature_spec = (
        tf_transform_output.transformed_feature_spec().copy()
    )

    dataset = tf.data.experimental.make_batched_features_dataset(
        file_pattern=file_pattern,
        batch_size=batch_size,
        features=transform_feature_spec,
        reader=_gzip_reader_fn,
        num_epochs=num_epochs,
        label_key=transformed_name(LABEL_KEY),
    )
    return dataset


# ──────────────────────────────────────────────
# Model builder
# ──────────────────────────────────────────────

def _build_keras_model(tf_transform_output):
    """
    Membangun arsitektur model Keras untuk klasifikasi churn.

    Arsitektur:
        - Input numerik: z-score normalized → dense layers
        - Input kategorik: embedding → flatten → dense layers
        - Concatenate → Dense(256) → Dropout → Dense(128) →
          Dropout → Dense(64) → Dense(1, sigmoid)

    Args:
        tf_transform_output: TFTransformOutput untuk mendapatkan vocab size.

    Returns:
        Compiled tf.keras.Model.
    """
    inputs = []
    encoded_inputs = []

    # ── Numerical inputs ──────────────────────────────────────────
    for feature in NUMERICAL_FEATURES:
        inp = tf.keras.Input(
            shape=(1,),
            name=transformed_name(feature),
            dtype=tf.float32,
        )
        inputs.append(inp)
        encoded_inputs.append(inp)

    # ── Categorical inputs (embedding) ────────────────────────────
    for feature in CATEGORICAL_FEATURES:
        vocab_size = tf_transform_output.vocabulary_size_by_name(feature)
        inp = tf.keras.Input(
            shape=(1,),
            name=transformed_name(feature),
            dtype=tf.int64,
        )
        emb = tf.keras.layers.Embedding(
            input_dim=vocab_size + 1,
            output_dim=EMBEDDING_DIM,
            name=f'embedding_{feature}',
        )(inp)
        emb = tf.keras.layers.Reshape(
            (EMBEDDING_DIM,), name=f'reshape_{feature}'
        )(emb)
        inputs.append(inp)
        encoded_inputs.append(emb)

    # ── Concatenate & Dense layers ────────────────────────────────
    x = tf.keras.layers.concatenate(encoded_inputs, name='concat')
    x = tf.keras.layers.Dense(256, activation='relu', name='dense_1')(x)
    x = tf.keras.layers.Dropout(0.3, name='dropout_1')(x)
    x = tf.keras.layers.Dense(128, activation='relu', name='dense_2')(x)
    x = tf.keras.layers.Dropout(0.3, name='dropout_2')(x)
    x = tf.keras.layers.Dense(64, activation='relu', name='dense_3')(x)
    output = tf.keras.layers.Dense(
        1, activation='sigmoid', name='output'
    )(x)

    model = tf.keras.Model(inputs=inputs, outputs=output)

    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
        loss='binary_crossentropy',
        metrics=[
            tf.keras.metrics.AUC(name='auc'),
            tf.keras.metrics.BinaryAccuracy(name='accuracy'),
            tf.keras.metrics.Precision(name='precision'),
            tf.keras.metrics.Recall(name='recall'),
        ],
    )
    return model


# ──────────────────────────────────────────────
# Serving functions
# ──────────────────────────────────────────────

def _get_serve_tf_examples_fn(model, tf_transform_output):
    """
    Serving function #1: menerima serialized tf.Example (bytes/b64).
    Digunakan oleh 'serving_default' signature.
    Cocok untuk request: {"instances": [{"b64": "..."}]}
    """
    @tf.function
    def serve_tf_examples_fn(serialized_tf_examples):
        feature_spec = tf_transform_output.raw_feature_spec()
        feature_spec.pop(LABEL_KEY)
        parsed_features = tf.io.parse_example(
            serialized_tf_examples, feature_spec
        )
        transformed_features = (
            tf_transform_output.transform_raw_features(parsed_features)
        )
        return model(transformed_features)

    return serve_tf_examples_fn


def _get_serve_raw_fn(model, tf_transform_output):
    """
    Serving function #2: menerima JSON key-value langsung (tanpa encode).
    Digunakan oleh 'from_examples' signature.
    Cocok untuk request curl biasa: {"instances": [{"Tenure": 3, ...}]}
    """
    @tf.function(input_signature=[{
        # Numerik → float
        'Tenure':                      tf.TensorSpec(shape=[None], dtype=tf.float32),
        'CityTier':                    tf.TensorSpec(shape=[None], dtype=tf.float32),
        'WarehouseToHome':             tf.TensorSpec(shape=[None], dtype=tf.float32),
        'HourSpendOnApp':              tf.TensorSpec(shape=[None], dtype=tf.float32),
        'NumberOfDeviceRegistered':    tf.TensorSpec(shape=[None], dtype=tf.float32),
        'SatisfactionScore':           tf.TensorSpec(shape=[None], dtype=tf.float32),
        'NumberOfAddress':             tf.TensorSpec(shape=[None], dtype=tf.float32),
        'Complain':                    tf.TensorSpec(shape=[None], dtype=tf.float32),
        'OrderAmountHikeFromlastYear': tf.TensorSpec(shape=[None], dtype=tf.float32),
        'CouponUsed':                  tf.TensorSpec(shape=[None], dtype=tf.float32),
        'OrderCount':                  tf.TensorSpec(shape=[None], dtype=tf.float32),
        'DaySinceLastOrder':           tf.TensorSpec(shape=[None], dtype=tf.float32),
        'CashbackAmount':              tf.TensorSpec(shape=[None], dtype=tf.float32),
        # Kategorik → string
        'PreferredLoginDevice':        tf.TensorSpec(shape=[None], dtype=tf.string),
        'PreferredPaymentMode':        tf.TensorSpec(shape=[None], dtype=tf.string),
        'Gender':                      tf.TensorSpec(shape=[None], dtype=tf.string),
        'PreferedOrderCat':            tf.TensorSpec(shape=[None], dtype=tf.string),
        'MaritalStatus':               tf.TensorSpec(shape=[None], dtype=tf.string),
    }])
    def serve_raw_fn(inputs):
        # Cast numerik ke float32
        raw = {}
        for feat in NUMERICAL_FEATURES:
            raw[feat] = tf.cast(inputs[feat], tf.float32)
        for feat in CATEGORICAL_FEATURES:
            raw[feat] = inputs[feat]
        transformed = tf_transform_output.transform_raw_features(raw)
        return model(transformed)

    return serve_raw_fn


# ──────────────────────────────────────────────
# Entry point TFX
# ──────────────────────────────────────────────

def run_fn(fn_args: FnArgs):
    """
    Fungsi utama yang dipanggil oleh TFX Trainer component.

    Args:
        fn_args: FnArgs berisi path ke data, model, dan konfigurasi training.
    """
    tf_transform_output = tft.TFTransformOutput(fn_args.transform_graph_path)

    train_dataset = _input_fn(
        fn_args.train_files,
        tf_transform_output,
        num_epochs=10,
        batch_size=64,
    )
    eval_dataset = _input_fn(
        fn_args.eval_files,
        tf_transform_output,
        num_epochs=1,
        batch_size=64,
    )

    model = _build_keras_model(tf_transform_output)
    model.summary()

    # ── Callbacks ─────────────────────────────────────────────────
    tensorboard_callback = tf.keras.callbacks.TensorBoard(
        log_dir=fn_args.model_run_dir,
        update_freq='batch',
    )
    early_stopping = tf.keras.callbacks.EarlyStopping(
        monitor='val_auc',
        patience=3,
        restore_best_weights=True,
        mode='max',
    )

    # ── Training ──────────────────────────────────────────────────
    model.fit(
        train_dataset,
        steps_per_epoch=fn_args.train_steps,
        validation_data=eval_dataset,
        validation_steps=fn_args.eval_steps,
        callbacks=[tensorboard_callback, early_stopping],
    )

    # ── Save model dengan 2 signatures ────────────────────────────
    # serving_default : terima serialized tf.Example (b64)
    # from_examples   : terima JSON key-value langsung (curl-friendly)
    signatures = {
        'serving_default': _get_serve_tf_examples_fn(
            model, tf_transform_output
        ).get_concrete_function(
            tf.TensorSpec(shape=[None], dtype=tf.string, name='examples')
        ),
        'from_examples': _get_serve_raw_fn(model, tf_transform_output),
    }

    model.save(
        fn_args.serving_model_dir,
        save_format='tf',
        signatures=signatures,
    )